//
//  Sitter_Cell.swift
//  Sitter_PetTab
//
//  Created by MU IT Program on 3/30/16.
//  Copyright © 2016 Megan Cochran. All rights reserved.
//

import UIKit

class CellSitter: UICollectionViewCell {
    
    @IBOutlet weak var petButton: UIButton!
    
}
